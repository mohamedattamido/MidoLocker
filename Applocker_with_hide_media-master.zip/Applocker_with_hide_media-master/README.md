## App locker

## Features:
       Lock the other app.
       show system apps and user app.
       search the applications for enable or disable locks.
       enable or disable lock using switch.
       Hide your Media like a photos..
       store your hidden data in form of grid.
       imagepicker for pick images from gallery.
       application running in background for better exprience.
       selected media hide from the gallery.
       


## Screenshots:



| Main Screen Of App Locker | Home Page |
|:-:|:-:|
| <img width="210" height="410" alt="main_screen" src="https://user-images.githubusercontent.com/52051877/75993799-0d014280-5f20-11ea-9023-4a5f54089af4.png"> | <img width="210" height="410" alt="screen_home" src="https://user-images.githubusercontent.com/52051877/75994297-c102cd80-5f20-11ea-90aa-de4db4327971.PNG"> |

| Hide Media Screen |Stored Hidden Data|
|:-:|:-:|
| <img width="210" height="410" alt="hide_activity" src="https://user-images.githubusercontent.com/52051877/75994372-e263b980-5f20-11ea-8319-04684ed267b2.PNG"> |  <img width="210" height="410" alt="hide_screen" src="https://user-images.githubusercontent.com/52051877/75994416-f60f2000-5f20-11ea-9a67-cea4f1bf4096.PNG">|
