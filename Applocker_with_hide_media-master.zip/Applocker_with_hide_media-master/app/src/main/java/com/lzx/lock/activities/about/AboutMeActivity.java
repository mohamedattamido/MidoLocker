package com.lzx.lock.activities.about;

import android.os.Bundle;

import com.lzx.lock.R;
import com.lzx.lock.base.BaseActivity;


public class AboutMeActivity extends BaseActivity {
    @Override
    public int getLayoutId() {
        return R.layout.activity_about_me;
    }

    @Override
    protected void initViews(Bundle savedInstanceState) {

    }

    @Override
    protected void initData() {

    }

    @Override
    protected void initAction() {

    }
}
