package com.lzx.lock.base;


public interface BasePresenter {
}
